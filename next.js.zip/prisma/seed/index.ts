import { db } from '../../src/lib/db'
import bcrypt from 'bcryptjs'

async function main() {
  console.log('Seeding database...')

  // Create admin user
  const hashedPassword = await bcrypt.hash('stecuadmin', 12)
  
  const admin = await db.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      email: 'admin@example.com',
      username: 'admin',
      password: hashedPassword,
      role: 'ADMIN',
      isVerified: true,
      isBanned: false,
    },
  })

  console.log('Admin user created:', admin)

  // Create some sample forums
  const forum1 = await db.forum.create({
    data: {
      name: 'General Discussion',
      description: 'A place for general discussions',
      createdBy: admin.id,
    },
  })

  const forum2 = await db.forum.create({
    data: {
      name: 'Technical Support',
      description: 'Get help with technical issues',
      createdBy: admin.id,
    },
  })

  console.log('Sample forums created:', forum1, forum2)

  // Add admin as member to forums
  await db.forumMember.createMany({
    data: [
      { userId: admin.id, forumId: forum1.id },
      { userId: admin.id, forumId: forum2.id },
    ],
  })

  console.log('Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })