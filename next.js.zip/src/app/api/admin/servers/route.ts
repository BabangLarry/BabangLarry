import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token and check if user is admin
    const decoded = jwt.verify(token, JWT_SECRET) as any
    if (decoded.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    // Fetch all servers
    const servers = await db.server.findMany({
      include: {
        user: {
          select: { username: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      servers: servers.map(server => ({
        id: server.id,
        username: server.username,
        password: server.password,
        loginLink: server.loginLink,
        userId: server.userId,
        user: server.user,
        createdAt: server.createdAt
      }))
    })
  } catch (error) {
    console.error('Servers fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token and check if user is admin
    const decoded = jwt.verify(token, JWT_SECRET) as any
    if (decoded.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    const { username, password, loginLink, userId } = await request.json()

    if (!username || !password || !loginLink || !userId) {
      return NextResponse.json(
        { error: 'All fields are required' },
        { status: 400 }
      )
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Create server
    const server = await db.server.create({
      data: {
        username,
        password,
        loginLink,
        userId
      },
      include: {
        user: {
          select: { username: true }
        }
      }
    })

    return NextResponse.json({
      message: 'Server created successfully',
      server: {
        id: server.id,
        username: server.username,
        password: server.password,
        loginLink: server.loginLink,
        userId: server.userId,
        user: server.user,
        createdAt: server.createdAt
      }
    })
  } catch (error) {
    console.error('Server creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}