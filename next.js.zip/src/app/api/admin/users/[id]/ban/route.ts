import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token and check if user is admin
    const decoded = jwt.verify(token, JWT_SECRET) as any
    if (decoded.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    const { isBanned } = await request.json()
    const userId = params.id

    // Update user ban status
    const user = await db.user.update({
      where: { id: userId },
      data: { isBanned }
    })

    return NextResponse.json({
      message: `User ${isBanned ? 'banned' : 'unbanned'} successfully`,
      user: {
        id: user.id,
        username: user.username,
        isBanned: user.isBanned
      }
    })
  } catch (error) {
    console.error('User ban error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}