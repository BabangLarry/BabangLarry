import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as any
    const userId = decoded.userId
    const forumId = params.id

    // Check if forum exists
    const forum = await db.forum.findUnique({
      where: { id: forumId, isDeleted: false }
    })

    if (!forum) {
      return NextResponse.json(
        { error: 'Forum not found' },
        { status: 404 }
      )
    }

    // Check if user is already a member
    const existingMember = await db.forumMember.findUnique({
      where: {
        userId_forumId: {
          userId,
          forumId
        }
      }
    })

    if (existingMember) {
      return NextResponse.json(
        { error: 'Already a member of this forum' },
        { status: 400 }
      )
    }

    // Add user as member
    await db.forumMember.create({
      data: {
        userId,
        forumId
      }
    })

    return NextResponse.json({
      message: 'Successfully joined forum'
    })
  } catch (error) {
    console.error('Forum join error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}