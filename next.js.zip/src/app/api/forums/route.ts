import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token
    jwt.verify(token, JWT_SECRET)

    // Fetch all forums with member and message counts
    const forums = await db.forum.findMany({
      where: { isDeleted: false },
      include: {
        creator: {
          select: { username: true }
        },
        _count: {
          select: {
            members: true,
            messages: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      forums: forums.map(forum => ({
        id: forum.id,
        name: forum.name,
        description: forum.description,
        createdBy: forum.createdBy,
        createdAt: forum.createdAt,
        creator: forum.creator,
        _count: forum._count
      }))
    })
  } catch (error) {
    console.error('Forums fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as any
    const userId = decoded.userId

    const { name, description } = await request.json()

    if (!name?.trim()) {
      return NextResponse.json(
        { error: 'Forum name is required' },
        { status: 400 }
      )
    }

    // Create forum
    const forum = await db.forum.create({
      data: {
        name: name.trim(),
        description: description?.trim() || null,
        createdBy: userId
      },
      include: {
        creator: {
          select: { username: true }
        }
      }
    })

    // Add creator as member
    await db.forumMember.create({
      data: {
        userId,
        forumId: forum.id
      }
    })

    return NextResponse.json({
      message: 'Forum created successfully',
      forum: {
        id: forum.id,
        name: forum.name,
        description: forum.description,
        createdBy: forum.createdBy,
        createdAt: forum.createdAt,
        creator: forum.creator
      }
    })
  } catch (error) {
    console.error('Forum creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}