import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as any
    const userId = decoded.userId

    // Fetch user's reports
    const reports = await db.report.findMany({
      where: { userId },
      include: {
        forum: {
          select: { name: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      reports: reports.map(report => ({
        id: report.id,
        forumName: report.forum.name,
        reason: report.reason,
        status: report.status,
        createdAt: report.createdAt
      }))
    })
  } catch (error) {
    console.error('Reports fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as any
    const userId = decoded.userId

    const formData = await request.formData()
    const forumName = formData.get('forumName') as string
    const reason = formData.get('reason') as string
    const forumId = formData.get('forumId') as string
    const evidence = formData.get('evidence') as File | null

    if (!forumName?.trim() || !reason?.trim()) {
      return NextResponse.json(
        { error: 'Forum name and reason are required' },
        { status: 400 }
      )
    }

    // Find forum by name or ID
    let forum
    if (forumId) {
      forum = await db.forum.findUnique({
        where: { id: forumId, isDeleted: false }
      })
    } else {
      forum = await db.forum.findFirst({
        where: { 
          name: { contains: forumName, mode: 'insensitive' },
          isDeleted: false
        }
      })
    }

    if (!forum) {
      return NextResponse.json(
        { error: 'Forum not found' },
        { status: 404 }
      )
    }

    // Handle evidence file upload (simplified - just store filename)
    let evidenceFilename = null
    if (evidence && evidence.size > 0) {
      evidenceFilename = evidence.name
    }

    // Create report
    const report = await db.report.create({
      data: {
        forumId: forum.id,
        userId,
        reason: reason.trim(),
        evidence: evidenceFilename,
        status: 'PENDING'
      }
    })

    // Create ticket
    await db.ticket.create({
      data: {
        reportId: report.id,
        userId,
        title: `Report for forum: ${forum.name}`,
        description: reason.trim(),
        status: 'OPEN'
      }
    })

    return NextResponse.json({
      message: 'Report submitted successfully',
      reportId: report.id
    })
  } catch (error) {
    console.error('Report creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}