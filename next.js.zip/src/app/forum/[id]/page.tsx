'use client'

import { useState, useEffect, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Send, Users, MessageSquare } from 'lucide-react'
import Link from 'next/link'
import { io, Socket } from 'socket.io-client'

interface Message {
  id: string
  content: string
  userId: string
  username: string
  createdAt: string
}

interface Forum {
  id: string
  name: string
  description?: string
  createdBy: string
  createdAt: string
  creator: {
    username: string
  }
}

interface User {
  id: string
  username: string
  role: string
}

export default function ForumChatPage() {
  const [forum, setForum] = useState<Forum | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<User | null>(null)
  const [isMember, setIsMember] = useState(false)
  const [socket, setSocket] = useState<Socket | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  
  const params = useParams()
  const router = useRouter()
  const forumId = params.id as string

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')

    if (!token || !userData) {
      router.push('/login')
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)
    
    // Initialize socket connection
    const socketInstance = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3000', {
      auth: {
        token
      }
    })
    
    setSocket(socketInstance)

    fetchForumData(token, forumId)
    checkMembership(token, forumId)

    // Join forum room
    socketInstance.emit('join_forum', { forumId })

    // Listen for new messages
    socketInstance.on('new_message', (message: Message) => {
      setMessages(prev => [...prev, message])
    })

    return () => {
      socketInstance.disconnect()
    }
  }, [forumId, router])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const fetchForumData = async (token: string, forumId: string) => {
    try {
      const response = await fetch(`/api/forums/${forumId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setForum(data.forum)
        setMessages(data.messages || [])
      }
    } catch (error) {
      console.error('Error fetching forum data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const checkMembership = async (token: string, forumId: string) => {
    try {
      const response = await fetch(`/api/forums/${forumId}/member`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setIsMember(data.isMember)
      }
    } catch (error) {
      console.error('Error checking membership:', error)
    }
  }

  const handleSendMessage = () => {
    if (!newMessage.trim() || !socket || !user) return

    socket.emit('send_message', {
      forumId,
      content: newMessage.trim(),
      userId: user.id,
      username: user.username
    })

    setNewMessage('')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-300">Loading forum...</p>
        </div>
      </div>
    )
  }

  if (!forum) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Forum Not Found
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-center mb-4">
              The forum you're looking for doesn't exist or has been deleted.
            </p>
            <Link href="/forum">
              <Button>Back to Forums</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!isMember) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Access Restricted
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-center mb-4">
              You need to join this forum to participate in discussions.
            </p>
            <Link href="/forum">
              <Button>Back to Forums</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/forum">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Forums
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {forum.name}
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {forum.description}
                </p>
              </div>
            </div>
            <Badge variant="secondary">
              Member
            </Badge>
          </div>
        </div>
      </header>

      {/* Chat Container */}
      <div className="flex-1 flex flex-col max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6">
        {/* Messages */}
        <div className="flex-1 bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-4 overflow-hidden flex flex-col">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <MessageSquare className="h-12 w-12 mb-4" />
                <p>No messages yet. Start the conversation!</p>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.userId === user?.id ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      message.userId === user?.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white'
                    }`}
                  >
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-xs font-medium">
                        {message.userId === user?.id ? 'You' : message.username}
                      </span>
                      <span className="text-xs opacity-70">
                        {new Date(message.createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <div className="border-t dark:border-gray-700 p-4">
            <div className="flex space-x-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
                size="sm"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}