'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Users, 
  Filter, 
  UserPlus, 
  Server, 
  LogOut, 
  Search,
  Settings,
  Database,
  Shield,
  AlertTriangle
} from 'lucide-react'

interface User {
  id: string
  username: string
  email: string
  role: string
  isBanned: boolean
  createdAt: string
}

interface Ticket {
  id: string
  title: string
  description: string
  status: string
  createdAt: string
  user: {
    username: string
  }
}

export default function AdminPage() {
  const [activeSection, setActiveSection] = useState('database')
  const [users, setUsers] = useState<User[]>([])
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')

    if (!token || !userData) {
      router.push('/login')
      return
    }

    const parsedUser = JSON.parse(userData)
    
    // Check if user is admin
    if (parsedUser.role !== 'ADMIN') {
      router.push('/dashboard')
      return
    }

    setUser(parsedUser)
    fetchUsers(token)
    fetchTickets(token)
  }, [router])

  const fetchUsers = async (token: string) => {
    try {
      const response = await fetch('/api/admin/users', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchTickets = async (token: string) => {
    try {
      const response = await fetch('/api/admin/tickets', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setTickets(data.tickets || [])
      }
    } catch (error) {
      console.error('Error fetching tickets:', error)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/login')
  }

  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN': return 'bg-yellow-100 text-yellow-800'
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800'
      case 'RESOLVED': return 'bg-green-100 text-green-800'
      case 'REJECTED': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'ADMIN': return 'bg-red-100 text-red-800'
      case 'MODERATOR': return 'bg-blue-100 text-blue-800'
      case 'MEMBER': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                Admin Dashboard
              </h1>
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                Administrator
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-300">
                Welcome, {user?.username}
              </span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="w-64 flex-shrink-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Admin Menu</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant={activeSection === 'database' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveSection('database')}
                >
                  <Database className="h-4 w-4 mr-2" />
                  Database Username
                </Button>
                <Button
                  variant={activeSection === 'filter' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveSection('filter')}
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filter Bantuan
                </Button>
                <Button
                  variant={activeSection === 'role' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveSection('role')}
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add Role Username
                </Button>
                <Button
                  variant={activeSection === 'server' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveSection('server')}
                >
                  <Server className="h-4 w-4 mr-2" />
                  Server Administrator
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeSection === 'database' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="h-5 w-5 mr-2" />
                    Database Username
                  </CardTitle>
                  <CardDescription>
                    Kelola data pengguna seperti pencarian username, ubah password, banned, dan hapus akun
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search users..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>

                  {isLoading ? (
                    <div className="space-y-4">
                      {[...Array(5)].map((_, i) => (
                        <Card key={i} className="animate-pulse">
                          <CardContent className="p-4">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredUsers.length === 0 ? (
                        <Card>
                          <CardContent className="flex flex-col items-center justify-center py-12">
                            <Users className="h-12 w-12 text-gray-400 mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                              No Users Found
                            </h3>
                            <p className="text-gray-600 dark:text-gray-300 text-center">
                              {searchTerm ? 'No users match your search criteria.' : 'No users in the database.'}
                            </p>
                          </CardContent>
                        </Card>
                      ) : (
                        filteredUsers.map((user) => (
                          <Card key={user.id}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-2">
                                <div>
                                  <h4 className="font-medium text-gray-900 dark:text-white">
                                    {user.username}
                                  </h4>
                                  <p className="text-sm text-gray-600 dark:text-gray-300">
                                    {user.email}
                                  </p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Badge className={getRoleColor(user.role)}>
                                    {user.role}
                                  </Badge>
                                  {user.isBanned && (
                                    <Badge variant="destructive">
                                      Banned
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <div className="flex justify-between items-center">
                                <p className="text-xs text-gray-500">
                                  Joined {new Date(user.createdAt).toLocaleDateString()}
                                </p>
                                <div className="flex space-x-2">
                                  <Button size="sm" variant="outline">
                                    Edit
                                  </Button>
                                  <Button size="sm" variant="outline">
                                    Reset PW
                                  </Button>
                                  {user.role !== 'ADMIN' && (
                                    <Button 
                                      size="sm" 
                                      variant={user.isBanned ? "outline" : "destructive"}
                                    >
                                      {user.isBanned ? 'Unban' : 'Ban'}
                                    </Button>
                                  )}
                                  {user.role !== 'ADMIN' && (
                                    <Button size="sm" variant="destructive">
                                      Delete
                                    </Button>
                                  )}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeSection === 'filter' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Filter className="h-5 w-5 mr-2" />
                    Filter Bantuan
                  </CardTitle>
                  <CardDescription>
                    Lihat dan kelola semua tiket bantuan yang diajukan oleh pengguna
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <Card key={i} className="animate-pulse">
                          <CardContent className="p-4">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {tickets.length === 0 ? (
                        <Card>
                          <CardContent className="flex flex-col items-center justify-center py-12">
                            <AlertTriangle className="h-12 w-12 text-gray-400 mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                              No Tickets Found
                            </h3>
                            <p className="text-gray-600 dark:text-gray-300 text-center">
                              No help tickets have been submitted yet.
                            </p>
                          </CardContent>
                        </Card>
                      ) : (
                        tickets.map((ticket) => (
                          <Card key={ticket.id}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-2">
                                <div>
                                  <h4 className="font-medium text-gray-900 dark:text-white">
                                    {ticket.title}
                                  </h4>
                                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                                    {ticket.description}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    By {ticket.user.username} • {new Date(ticket.createdAt).toLocaleDateString()}
                                  </p>
                                </div>
                                <Badge className={getStatusColor(ticket.status)}>
                                  {ticket.status}
                                </Badge>
                              </div>
                              <div className="flex justify-end space-x-2">
                                <Button size="sm" variant="outline">
                                  View Details
                                </Button>
                                {ticket.status === 'OPEN' && (
                                  <>
                                    <Button size="sm" variant="default">
                                      Accept
                                    </Button>
                                    <Button size="sm" variant="destructive">
                                      Reject
                                    </Button>
                                  </>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeSection === 'role' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <UserPlus className="h-5 w-5 mr-2" />
                    Add Role Username
                  </CardTitle>
                  <CardDescription>
                    Berikan role kepada pengguna (Moderator, Admin, Member)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="max-w-md">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="username">Username</Label>
                        <Input
                          id="username"
                          placeholder="Enter username"
                        />
                      </div>
                      <div>
                        <Label htmlFor="role">Role</Label>
                        <select
                          id="role"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="MEMBER">Member</option>
                          <option value="MODERATOR">Moderator</option>
                          <option value="ADMIN">Admin</option>
                        </select>
                      </div>
                      <Button className="w-full">
                        Update Role
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === 'server' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Server className="h-5 w-5 mr-2" />
                    Server Administrator
                  </CardTitle>
                  <CardDescription>
                    Tambahkan atau hapus server untuk pengguna
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="max-w-md">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="serverUsername">Username</Label>
                        <Input
                          id="serverUsername"
                          placeholder="Enter server username"
                        />
                      </div>
                      <div>
                        <Label htmlFor="serverPassword">Password</Label>
                        <Input
                          id="serverPassword"
                          type="password"
                          placeholder="Enter server password"
                        />
                      </div>
                      <div>
                        <Label htmlFor="loginLink">Login Link</Label>
                        <Input
                          id="loginLink"
                          placeholder="Enter login link"
                        />
                      </div>
                      <div>
                        <Label htmlFor="targetUser">Target User</Label>
                        <Input
                          id="targetUser"
                          placeholder="Enter username to assign server"
                        />
                      </div>
                      <Button className="w-full">
                        Add Server
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}