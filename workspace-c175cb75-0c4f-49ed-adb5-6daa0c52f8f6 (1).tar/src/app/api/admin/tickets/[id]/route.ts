import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token and check if user is admin
    const decoded = jwt.verify(token, JWT_SECRET) as any
    if (decoded.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    const { status, adminNotes } = await request.json()
    const ticketId = params.id

    // Update ticket status
    const ticket = await db.ticket.update({
      where: { id: ticketId },
      data: {
        status,
        ...(adminNotes && { adminNotes })
      }
    })

    return NextResponse.json({
      message: 'Ticket updated successfully',
      ticket: {
        id: ticket.id,
        status: ticket.status,
        adminNotes: ticket.adminNotes
      }
    })
  } catch (error) {
    console.error('Ticket update error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}