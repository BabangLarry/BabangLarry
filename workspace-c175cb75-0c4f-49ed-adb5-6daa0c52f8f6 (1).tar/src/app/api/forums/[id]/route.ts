import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    // Verify token
    jwt.verify(token, JWT_SECRET)

    const forumId = params.id

    // Fetch forum details
    const forum = await db.forum.findUnique({
      where: { id: forumId, isDeleted: false },
      include: {
        creator: {
          select: { username: true }
        },
        _count: {
          select: {
            members: true,
            messages: true
          }
        }
      }
    })

    if (!forum) {
      return NextResponse.json(
        { error: 'Forum not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      forum: {
        id: forum.id,
        name: forum.name,
        description: forum.description,
        createdBy: forum.createdBy,
        createdAt: forum.createdAt,
        creator: forum.creator,
        _count: forum._count
      }
    })
  } catch (error) {
    console.error('Forum fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}