'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { MessageSquare, Plus, Users, AlertTriangle, ArrowLeft, Search } from 'lucide-react'
import Link from 'next/link'

interface Forum {
  id: string
  name: string
  description?: string
  createdBy: string
  createdAt: string
  creator: {
    username: string
  }
  _count?: {
    members: number
    messages: number
  }
}

interface User {
  id: string
  username: string
  role: string
}

export default function ForumPage() {
  const [forums, setForums] = useState<Forum[]>([])
  const [filteredForums, setFilteredForums] = useState<Forum[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<User | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newForum, setNewForum] = useState({ name: '', description: '' })
  const [isCreating, setIsCreating] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')

    if (!token || !userData) {
      router.push('/login')
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)
    fetchForums(token)
  }, [router])

  useEffect(() => {
    if (searchTerm) {
      const filtered = forums.filter(forum =>
        forum.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        forum.description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
      setFilteredForums(filtered)
    } else {
      setFilteredForums(forums)
    }
  }, [searchTerm, forums])

  const fetchForums = async (token: string) => {
    try {
      const response = await fetch('/api/forums', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setForums(data.forums || [])
        setFilteredForums(data.forums || [])
      }
    } catch (error) {
      console.error('Error fetching forums:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateForum = async () => {
    if (!newForum.name.trim()) return

    setIsCreating(true)
    const token = localStorage.getItem('token')

    try {
      const response = await fetch('/api/forums', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newForum)
      })

      if (response.ok) {
        setNewForum({ name: '', description: '' })
        setIsCreateDialogOpen(false)
        fetchForums(token!)
      }
    } catch (error) {
      console.error('Error creating forum:', error)
    } finally {
      setIsCreating(false)
    }
  }

  const handleJoinForum = async (forumId: string) => {
    const token = localStorage.getItem('token')

    try {
      const response = await fetch(`/api/forums/${forumId}/join`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        router.push(`/forum/${forumId}`)
      }
    } catch (error) {
      console.error('Error joining forum:', error)
    }
  }

  const handleReportForum = async (forumId: string) => {
    router.push(`/help?forumId=${forumId}`)
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                Forums
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search forums..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Forum
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Forum</DialogTitle>
                    <DialogDescription>
                      Create a new forum for discussions
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="forum-name">Forum Name</Label>
                      <Input
                        id="forum-name"
                        placeholder="Enter forum name"
                        value={newForum.name}
                        onChange={(e) => setNewForum({ ...newForum, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="forum-description">Description</Label>
                      <Textarea
                        id="forum-description"
                        placeholder="Enter forum description"
                        value={newForum.description}
                        onChange={(e) => setNewForum({ ...newForum, description: e.target.value })}
                      />
                    </div>
                    <Button 
                      onClick={handleCreateForum} 
                      disabled={isCreating || !newForum.name.trim()}
                      className="w-full"
                    >
                      {isCreating ? 'Creating...' : 'Create Forum'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredForums.length === 0 ? (
              <Card className="col-span-full">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <MessageSquare className="h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    {searchTerm ? 'No Forums Found' : 'No Forums Yet'}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 text-center">
                    {searchTerm 
                      ? 'No forums match your search criteria.'
                      : 'Be the first to create a forum and start discussions!'
                    }
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredForums.map((forum) => (
                <Card key={forum.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{forum.name}</CardTitle>
                        <CardDescription>
                          Created by {forum.creator.username} • {new Date(forum.createdAt).toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleReportForum(forum.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <AlertTriangle className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {forum.description || 'No description available'}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          {forum._count?.members || 0} members
                        </div>
                        <div className="flex items-center">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          {forum._count?.messages || 0} messages
                        </div>
                      </div>
                      <Button
                        onClick={() => handleJoinForum(forum.id)}
                        size="sm"
                      >
                        Join Forum
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </main>
    </div>
  )
}