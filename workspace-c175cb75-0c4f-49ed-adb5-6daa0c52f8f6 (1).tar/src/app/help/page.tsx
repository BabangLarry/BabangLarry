'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { AlertTriangle, FileText, Ticket, ArrowLeft, Upload, CheckCircle } from 'lucide-react'
import Link from 'next/link'

interface Report {
  id: string
  forumName: string
  reason: string
  status: string
  createdAt: string
}

interface User {
  id: string
  username: string
  role: string
}

export default function HelpPage() {
  const [reports, setReports] = useState<Report[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<User | null>(null)
  const [activeTab, setActiveTab] = useState('laporan')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [forumId, setForumId] = useState('')
  const [formData, setFormData] = useState({
    forumName: '',
    reason: '',
    evidence: null as File | null,
    agreeToTerms: false
  })
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')

    if (!token || !userData) {
      router.push('/login')
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)

    // Check if forumId is in URL params
    const forumParam = searchParams.get('forumId')
    if (forumParam) {
      setForumId(forumParam)
      // Fetch forum name
      fetchForumName(forumParam, token)
    }

    fetchReports(token)
  }, [router, searchParams])

  const fetchForumName = async (id: string, token: string) => {
    try {
      const response = await fetch(`/api/forums/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setFormData(prev => ({
          ...prev,
          forumName: data.forum.name
        }))
      }
    } catch (error) {
      console.error('Error fetching forum:', error)
    }
  }

  const fetchReports = async (token: string) => {
    try {
      const response = await fetch('/api/reports', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setReports(data.reports || [])
      }
    } catch (error) {
      console.error('Error fetching reports:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({
        ...prev,
        evidence: e.target.files![0]
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.forumName.trim() || !formData.reason.trim() || !formData.agreeToTerms) {
      return
    }

    setIsSubmitting(true)

    const token = localStorage.getItem('token')
    const submitData = new FormData()
    submitData.append('forumName', formData.forumName)
    submitData.append('reason', formData.reason)
    if (formData.evidence) {
      submitData.append('evidence', formData.evidence)
    }
    if (forumId) {
      submitData.append('forumId', forumId)
    }

    try {
      const response = await fetch('/api/reports', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: submitData
      })

      if (response.ok) {
        setSubmitSuccess(true)
        setFormData({
          forumName: '',
          reason: '',
          evidence: null,
          agreeToTerms: false
        })
        setForumId('')
        fetchReports(token!)
      }
    } catch (error) {
      console.error('Error submitting report:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'REVIEWED': return 'bg-blue-100 text-blue-800'
      case 'RESOLVED': return 'bg-green-100 text-green-800'
      case 'REJECTED': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/forum">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Forums
                </Button>
              </Link>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                Help & Support
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-300">
                Welcome, {user?.username}
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="w-64 flex-shrink-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Menu</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant={activeTab === 'laporan' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveTab('laporan')}
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Laporan
                </Button>
                <Button
                  variant={activeTab === 'ticket' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveTab('ticket')}
                >
                  <Ticket className="h-4 w-4 mr-2" />
                  Ticket Laporan
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'laporan' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    Laporkan Forum
                  </CardTitle>
                  <CardDescription>
                    Laporkan forum yang melanggar aturan atau tidak pantas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {submitSuccess ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                        Laporan Berhasil Dikirim!
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300">
                        Laporan Anda sedang ditindak lanjuti oleh admin.
                      </p>
                      <Button
                        onClick={() => setSubmitSuccess(false)}
                        className="mt-4"
                      >
                        Buat Laporan Lain
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <Label htmlFor="forumName">Nama Forum</Label>
                        <Input
                          id="forumName"
                          placeholder="Masukkan nama forum"
                          value={formData.forumName}
                          onChange={(e) => setFormData(prev => ({ ...prev, forumName: e.target.value }))}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="reason">Alasan Laporan</Label>
                        <Textarea
                          id="reason"
                          placeholder="Jelaskan alasan Anda melaporkan forum ini"
                          value={formData.reason}
                          onChange={(e) => setFormData(prev => ({ ...prev, reason: e.target.value }))}
                          required
                          className="min-h-[120px]"
                        />
                      </div>

                      <div>
                        <Label htmlFor="evidence">Upload Bukti (Opsional)</Label>
                        <div className="mt-2">
                          <Input
                            id="evidence"
                            type="file"
                            accept="image/*,.pdf"
                            onChange={handleFileChange}
                            className="cursor-pointer"
                          />
                          {formData.evidence && (
                            <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
                              File selected: {formData.evidence.name}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="agreeToTerms"
                          checked={formData.agreeToTerms}
                          onCheckedChange={(checked) => 
                            setFormData(prev => ({ ...prev, agreeToTerms: checked as boolean }))
                          }
                        />
                        <Label htmlFor="agreeToTerms" className="text-sm">
                          Saya menyetujui kebijakan dan ketentuan yang berlaku
                        </Label>
                      </div>

                      <Button
                        type="submit"
                        disabled={isSubmitting || !formData.forumName.trim() || !formData.reason.trim() || !formData.agreeToTerms}
                        className="w-full"
                      >
                        {isSubmitting ? 'Mengirim...' : 'Kirim Laporan'}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'ticket' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Ticket className="h-5 w-5 mr-2" />
                    Ticket Laporan Saya
                  </CardTitle>
                  <CardDescription>
                    Lihat status laporan yang telah Anda buat
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <Card key={i} className="animate-pulse">
                          <CardContent className="p-4">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : reports.length === 0 ? (
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                        Belum Ada Laporan
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300">
                        Anda belum membuat laporan apa pun.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {reports.map((report) => (
                        <Card key={report.id}>
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium text-gray-900 dark:text-white">
                                {report.forumName}
                              </h4>
                              <Badge className={getStatusColor(report.status)}>
                                {report.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                              {report.reason}
                            </p>
                            <p className="text-xs text-gray-500">
                              Dibuat pada {new Date(report.createdAt).toLocaleDateString()}
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}