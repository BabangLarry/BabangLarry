import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // Authenticate socket connection
    socket.use((packet, next) => {
      const token = socket.handshake.auth.token;
      
      if (!token) {
        return next(new Error('Authentication error'));
      }

      try {
        const decoded = jwt.verify(token, JWT_SECRET);
        socket.data.user = decoded;
        next();
      } catch (err) {
        next(new Error('Authentication error'));
      }
    });

    // Join forum room
    socket.on('join_forum', ({ forumId }) => {
      socket.join(`forum_${forumId}`);
      console.log(`User ${socket.data.user?.userId} joined forum ${forumId}`);
    });

    // Handle sending messages
    socket.on('send_message', async (data) => {
      try {
        const { forumId, content, userId, username } = data;
        
        // Verify the user matches the authenticated user
        if (userId !== socket.data.user?.userId) {
          socket.emit('error', { message: 'Unauthorized' });
          return;
        }

        // Create message in database
        const { db } = await import('@/lib/db');
        const message = await db.forumMessage.create({
          data: {
            content,
            userId,
            forumId
          },
          include: {
            user: {
              select: { username: true }
            }
          }
        });

        // Broadcast message to all users in the forum
        io.to(`forum_${forumId}`).emit('new_message', {
          id: message.id,
          content: message.content,
          userId: message.userId,
          username: message.user.username,
          createdAt: message.createdAt
        });

      } catch (error) {
        console.error('Error sending message:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });
};